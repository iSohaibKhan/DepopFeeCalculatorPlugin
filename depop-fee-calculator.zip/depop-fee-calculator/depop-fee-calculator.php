<?php
/*
Plugin Name: Depop Fee Calculator Shortcode
Plugin URI: https://sellercave.com/depop-fee-calculator/
Description: Shortcode [depop_fee_calculator] — responsive Depop fee calculator for calculating the fee shipping rates. Inherits theme colors & typography via CSS variables.
Version: 1.0.0
Author: Sohaib S. Khan
Author URI: https://isohaibkhan.github.io/
Text Domain: depop-fee-calculator
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function depop_register_assets() {
    wp_register_style('depop-fee-calculator-css', plugins_url('assets/css/depop-fee-calculator.css', __FILE__));
    wp_register_script('depop-fee-calculator-js', plugins_url('assets/js/depop-fee-calculator.js', __FILE__), array('jquery'), '1.0', true);

    // Rates and currency mapping passed to JS. You can filter this array via 'depop_calc_rates' filter.
    $rates = array(
        'United States' => array(
            'currency' => '$',
            'code' => 'USD',
            'depopPayments' => array('rate' => 0.033, 'fixed' => 0.45),
            'paypal' => array('rate' => 0.0349, 'fixed' => 0.49),
            'sellerFee' => 0.0
        ),
        'United Kingdom' => array(
            'currency' => '£',
            'code' => 'GBP',
            'depopPayments' => array('rate' => 0.029, 'fixed' => 0.30),
            'paypal' => array('rate' => 0.0349, 'fixed' => 0.49),
            'sellerFee' => 0.0
        ),
        'Australia' => array(
            'currency' => 'A$',
            'code' => 'AUD',
            'depopPayments' => array('rate' => 0.033, 'fixed' => 0.45),
            'paypal' => array('rate' => 0.0349, 'fixed' => 0.49),
            'sellerFee' => 0.0
        ),
        'Others' => array(
            'currency' => '$',
            'code' => 'USD',
            // For "Others" Depop has a 10% selling fee (historical behaviour).
            'depopPayments' => array('rate' => 0.10, 'fixed' => 0.00),
            'paypal' => array('rate' => 0.0349, 'fixed' => 0.49),
            'sellerFee' => 0.10
        ),
    );

    /**
     * Filter the rate mapping used by the Depop calculator.
     * Allows theme or other plugins to modify any rates or symbols.
     * Example: add_filter('depop_calc_rates', function($r){ $r['United States']['depopPayments']['rate'] = 0.04; return $r; });
     */
    $rates = apply_filters('depop_calc_rates', $rates);

    wp_localize_script('depop-fee-calculator-js', 'DepopCalcData', array(
        'rates' => $rates,
        'strings' => array(
            'boostInfo' => "Boosted items have an additional 8% fee on the item price (and shipping for certain sellers)",
        )
    ));
}
add_action('wp_enqueue_scripts', 'depop_register_assets');

function depop_fee_calculator_shortcode($atts = array()){
    // Enqueue when shortcode is used
    wp_enqueue_style('depop-fee-calculator-css');
    wp_enqueue_script('depop-fee-calculator-js');

    ob_start();
    ?>
    <div class="depop-calc" aria-live="polite">
        <div class="card">
            <div class="top-row">
                <label class="label">Your Email <span class="required">*</span></label>
                <div class="email-row">
                    <div class="email-input-wrap">
                        <span class="email-icon">✉️</span>
                        <input id="depop-email" type="email" placeholder="you@example.com" aria-label="Your email" />
                    </div>
                    <button id="depop-confirm-email" class="btn" type="button">Confirm Email</button>
                    <button id="depop-clear" class="btn btn-outline" type="button">Clear All</button>
                </div>
                <p class="help-text">Required for your fee calculation</p>
            </div>

            <div class="grid">
                <div class="form-group">
                    <label>Seller Location</label>
                    <select id="depop-location">
                        <option>United States</option>
                        <option>United Kingdom</option>
                        <option>Australia</option>
                        <option>Others</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Payment Processor</label>
                    <select id="depop-processor">
                        <option>Depop Payments</option>
                        <option>Paypal</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Shipping Method</label>
                    <select id="depop-shipping-method">
                        <option>Depop Shipping</option>
                        <option>Own Shipping</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Selling Price ($)</label>
                    <input id="depop-selling-price" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group">
                    <label>Shipping Cost ($)</label>
                    <input id="depop-shipping-cost" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group">
                    <label>Item Cost ($)</label>
                    <input id="depop-item-cost" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group checkbox-wrap">
                    <label class="checkbox"><input id="depop-boosted" type="checkbox" /> Boosted Item <button id="depop-boost-info" class="info" aria-label="Boost info">i</button></label>
                </div>
            </div>

            <div class="results" id="depop-results" aria-hidden="true">
                <div class="result-row"><div class="label">Payment Processing Fee:</div><div class="value" id="res-processing">-</div></div>
                <div class="result-row"><div class="label">Boosting Fee (8%):</div><div class="value" id="res-boosting">-</div></div>
                <div class="result-row"><div class="label">Shipping Cost:</div><div class="value" id="res-shipping">-</div></div>
                <div class="result-row total"><div class="label">Total Fees:</div><div class="value" id="res-total">-</div></div>
                <div class="result-row"><div class="label">Your Earnings:</div><div class="value" id="res-earnings">-</div></div>
                <div class="result-row"><div class="label">Your Profit:</div><div class="value" id="res-profit">-</div></div>
                <div class="result-row"><div class="label">Profit Margin:</div><div class="value" id="res-margin">-</div></div>
            </div>
        </div>

        <!-- Modal for boost info -->
        <div id="depop-modal" class="modal" role="dialog" aria-modal="true" aria-hidden="true">
            <div class="modal-content">
                <button id="depop-modal-close" class="modal-close" aria-label="Close">×</button>
                <p id="depop-modal-text"><?php echo esc_html( "Boosted items have an additional 8% fee on the item price (and shipping for certain sellers)" ); ?></p>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('depop_fee_calculator', 'depop_fee_calculator_shortcode');