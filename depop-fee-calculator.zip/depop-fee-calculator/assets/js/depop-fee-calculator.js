(function(){
    function qs(sel, el) { return (el || document).querySelector(sel); }
    function qsa(sel, el) { return (el || document).querySelectorAll(sel); }

    var rates = (window.DepopCalcData && window.DepopCalcData.rates) ? window.DepopCalcData.rates : {};
    var strings = (window.DepopCalcData && window.DepopCalcData.strings) ? window.DepopCalcData.strings : {};

    document.addEventListener('DOMContentLoaded', function(){
        var root = qs('.depop-calc');
        if(!root) return;

        var email = qs('#depop-email', root);
        var confirmBtn = qs('#depop-confirm-email', root);
        var clearBtn = qs('#depop-clear', root);

        var inputs = [
            qs('#depop-location', root),
            qs('#depop-processor', root),
            qs('#depop-shipping-method', root),
            qs('#depop-selling-price', root),
            qs('#depop-shipping-cost', root),
            qs('#depop-item-cost', root),
            qs('#depop-boosted', root)
        ];

        var results = qs('#depop-results', root);
        var resProcessing = qs('#res-processing', root);
        var resBoosting = qs('#res-boosting', root);
        var resShipping = qs('#res-shipping', root);
        var resTotal = qs('#res-total', root);
        var resEarnings = qs('#res-earnings', root);
        var resProfit = qs('#res-profit', root);
        var resMargin = qs('#res-margin', root);

        var modal = qs('#depop-modal', root);
        var modalText = qs('#depop-modal-text', root);
        var modalClose = qs('#depop-modal-close', root);
        var boostInfoBtn = qs('#depop-boost-info', root);
        if(boostInfoBtn){ boostInfoBtn.addEventListener('click', function(e){
            modalText.textContent = strings.boostInfo || 'Boosted items have an additional 8% fee on the item price (and shipping for certain sellers)';
            modal.style.display = 'flex'; modal.setAttribute('aria-hidden','false');
        });
        }
        modalClose.addEventListener('click', function(){ modal.style.display='none'; modal.setAttribute('aria-hidden','true'); });
        modal.addEventListener('click', function(e){ if(e.target === modal){ modal.style.display='none'; modal.setAttribute('aria-hidden','true'); } });

        function setDisabledState(disabled){
            inputs.forEach(function(i){ if(i){ i.disabled = disabled; } });
            if(disabled){ root.classList.add('depop-disabled'); results.style.display = 'none'; }
            else { root.classList.remove('depop-disabled'); results.style.display = 'block'; }
        }

        // Initially disabled until email confirmed
        setDisabledState(true);

        confirmBtn.addEventListener('click', function(){
            var val = email.value.trim();
            if(!val || !/\S+@\S+\.\S+/.test(val)){
                alert('Please enter a valid email to continue');
                return;
            }
            confirmBtn.textContent = '✔ Email Confirmed';
            confirmBtn.disabled = true;
            setDisabledState(false);
            calculate();
        });

        clearBtn.addEventListener('click', function(){
            email.value = '';
            confirmBtn.textContent = 'Confirm Email';
            confirmBtn.disabled = false;
            // reset all inputs
            inputs.forEach(function(i){ if(i){ if(i.type === 'checkbox') i.checked = false; else i.value = ''; } });
            setDisabledState(true);
            // clear results
            [resProcessing,resBoosting,resShipping,resTotal,resEarnings,resProfit,resMargin].forEach(function(el){ el.textContent='-'; el.classList.remove('positive','negative'); });
        });

        // Recalc on change
        inputs.forEach(function(i){ if(!i) return; i.addEventListener('input', calculate); i.addEventListener('change', calculate); });

        function getRateFor(location, processor){
            var loc = rates[location] || rates['Others'];
            if(!loc) return null;
            var lower = (processor||'').toLowerCase();
            if(lower.indexOf('depop') !== -1) return loc.depopPayments || null;
            return loc.paypal || null;
        }

        function formatCurrency(val, symbol){
            if(isNaN(val)) return '-';
            // if negative, put minus sign
            var fixed = Number(val).toFixed(2);
            return symbol + fixed;
        }

        function calculate(){
            var location = (qs('#depop-location', root).value || 'United States');
            var processor = (qs('#depop-processor', root).value || 'Depop Payments');
            var shippingMethod = (qs('#depop-shipping-method', root).value || 'Depop Shipping');
            var selling = parseFloat(qs('#depop-selling-price', root).value) || 0;
            var shipping = parseFloat(qs('#depop-shipping-cost', root).value) || 0;
            var itemCost = parseFloat(qs('#depop-item-cost', root).value) || 0;
            var boosted = qs('#depop-boosted', root).checked;

            var currency = (rates[location] && rates[location].currency) ? rates[location].currency : '$';
            var sellerFeeRate = (rates[location] && rates[location].sellerFee) ? parseFloat(rates[location].sellerFee) : 0;

            var baseForProcessing = selling + shipping; // processing applies to sale total
            var procRateObj = getRateFor(location, processor);
            var processingFee = 0;
            if(procRateObj){
                processingFee = (baseForProcessing * (procRateObj.rate || 0)) + (procRateObj.fixed || 0);
            }

            // Boosting fee: charged on item sale price and shipping if own shipping
            var boostBase = selling + ( (shippingMethod === 'Own Shipping') ? shipping : 0 );
            var boostingFee = boosted ? (boostBase * 0.08) : 0;

            // Depop seller fee (for some "Others") - charged on sale total (excluding taxes)
            var depopSellerFee = sellerFeeRate ? ((selling + ((shippingMethod === 'Own Shipping') ? shipping : 0)) * sellerFeeRate) : 0;

            var totalFees = processingFee + boostingFee + depopSellerFee;

            var earnings = (selling + shipping) - processingFee - boostingFee - depopSellerFee;

            var profit = earnings - itemCost;
            var margin = selling > 0 ? (profit / selling) * 100 : 0;

            // round to 2 decimals
            processingFee = Number(processingFee.toFixed(2));
            boostingFee = Number(boostingFee.toFixed(2));
            depopSellerFee = Number(depopSellerFee.toFixed(2));
            totalFees = Number(totalFees.toFixed(2));
            earnings = Number(earnings.toFixed(2));
            profit = Number(profit.toFixed(2));
            margin = Number(margin.toFixed(1));

            resProcessing.textContent = formatCurrency(processingFee, currency);
            resBoosting.textContent = formatCurrency(boostingFee, currency);
            resShipping.textContent = formatCurrency(shipping, currency);
            resTotal.textContent = formatCurrency(totalFees, currency);
            resEarnings.textContent = formatCurrency(earnings, currency);
            resProfit.textContent = formatCurrency(profit, currency);
            resMargin.textContent = margin + '%';

            // color classes
            [resEarnings,resProfit].forEach(function(el){ el.classList.remove('positive','negative'); if(parseFloat(el.textContent.replace(/[^0-9.-]+/g,'')) >= 0) el.classList.add('positive'); else el.classList.add('negative'); });
        }

    });
})();