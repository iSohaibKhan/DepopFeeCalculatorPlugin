* **Shortcode**: use `[depop_fee_calculator]` in any post/page/widget (text/html) to show the calculator.
* **Design & theme integration**: the CSS intentionally uses `font-family: inherit; color: inherit;` and CSS variables like `--wp--preset--color--primary` and `--e-global-color-primary` so the button color and typography are pulled from the theme/Elementor when available. If you want to force the button to follow your theme, add in your theme or Elementor "custom CSS":

* **Boosted item popup text** is set to: `Boosted items have an additional 8% fee on the item price (and shipping for certain sellers)`.

* **Responsive**: on narrow screens the grid collapses to single column.

* **Where the fee numbers come from** (sources used to populate defaults):

  * Depop Payments (US 3.3% + \$0.45; UK 2.9% + £0.30). See Crosslist / ClosetMojo references.
  * Boosted fee 8% — official Depop help.
  * Depop seller fee 10% for sellers outside US/UK (historical/other regions).

  These are bundled as default values but you should keep them up-to-date by modifying the `depop_calc_rates` filter if needed.
